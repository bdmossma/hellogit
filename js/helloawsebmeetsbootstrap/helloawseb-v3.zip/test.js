

var jsonObj = {"message":"usersResp","result":true,"resultMsg":[["otis.milo@email.com",{"firstName":"Otis","lastName":"Milo","password":"password","loggedIn":false}],["daisy.duke@email.com",{"firstName":"Daisy","lastName":"Duke","password":"password","loggedIn":false}]]};
var users = jsonObj.resultMsg;

for (var userIndex in users) {
	console.log(users[userIndex][0]);
}
